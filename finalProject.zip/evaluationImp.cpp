#include<iostream>
#include<string>
#include <conio.h>
#include <regex>
#include <sstream>
#include"myHeader.h"

using namespace std;


char getMenuChoiceOK(int maxMenuNumber)
{
	char choice;
	while(true)
	{
		choice = _getch();
		cout <<  choice;
		if ( ((int) choice > 48   && (int) choice <= maxMenuNumber + 48 ) )
		{
			return (int) choice - 48;
		}
		cout << "\n\tInavlide!Try again : ";
	}
}


int intValue(int maxNumber, string message)
{
	 const regex REGEX_ONLYNUMBERS("^[0-9]*$");
	 string number;
	 cout << "\n\t" << message << " (" << maxNumber << " digits): ";
	 do
	 {
		getline(cin,number);
		
		if (number.length() == maxNumber  &&  regex_match(number, REGEX_ONLYNUMBERS))
		{
			int intNumber;
			istringstream ( number ) >> intNumber;
			return intNumber;
        }
        else
        {
            cout << "\n\tInvalid entry!\n\t" << message << " (" << maxNumber << " digits): ";
        }
	}while(true);
}


string strValue(string message)
{
	 const regex REGEX_ONLYNUMBERS("^[a-zA-Z ]*$");
	 string jString;
	 cout << "\n\t" << message << ": ";
	 do
	 {
		getline(cin,jString);
		
		if (regex_match(jString, REGEX_ONLYNUMBERS))
		{	
			return jString;
        }
        else
        {
            cout << "\n\tInvalid entry!\n\t" << message << " : ";
        }
	}while(true);
}


string firstLettersCapital(string str)
{
	str[0] = toupper(str[0]);
	bool spaceOccurance = false;
	for (int i = 1; i < str.length(); i++)
	{
		if (str[i] != ' ')
		{
			if (spaceOccurance ==  false)
			{
				str[i] = tolower(str[i]);
			}
			else
			{
				str[i] = toupper(str[i]);
				spaceOccurance =  false;
			}
		}
		else
		{
			spaceOccurance =  true;
		}
	}
	return str;
}


string removeExcessSpace(string str)
{
	string jStr = str;
	bool oneSpace = false;
	int index = 0;
	if (str[0] == ' ')
	{
		oneSpace = true;

	}
	
	for (int i = 0; i < str.length(); i++)
	{
		if (oneSpace == false )//    dc  vvv
		{
			jStr[index] = str[i];
			index++;
			if (str[i] == ' ')
			{
				oneSpace = true;
			}
		}
		else
		{
			if (str[i] != ' ')
			{
				oneSpace = false;
				jStr[index] = str[i];
				index++;
			}
		}
	}
	for (int i = index; i < str.length(); i++)
	{
		jStr[i] = ' ';
	}
	return jStr;
}


string shortenString(string str,int length)
{
	if (str.length() > length)
	{
		str = str.substr(0,length-3);
	}
	return str + "...";
}

char myYesNo(string message)
{
	char choice;
	cout << "\n\n\t" << message << "(y/n)?";
	while(true)
	{
		choice = _getch();
		if ( toupper (choice) == 'Y' || toupper (choice) == 'N' )
		{
			return toupper (choice);
		}
	}
}

char exitByCTRLX()
{
		char choice;
	cout << "\n\t" << "Enter" << "(y/n)?";
	while(true)
	{
		choice = _getch();
		if ( toupper (choice) == 'X'  )
		{
			return toupper (choice);
		}
		cout << (int) choice;
	}
}

int exitPrompt(string message, int exitValue)
{
	if (myYesNo("Are you sure you want to exit program?") == 'Y')
	{
		//goodByPage();
		return exitValue;
	}else
	{
		return 0;
	}
}

bool checkIdDuplication(UserProfile arrUserProfile[], int &counter, int newID)
{
	for (int i = 0; i < counter; i++)
	{
		if (arrUserProfile[i].userID == newID)
		{
			cout << "\n\tDuplicate ID! Try again (7 digit number): ";
			return false;
		}
	}
	return true;
}